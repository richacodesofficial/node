# @floating-ui/utils

Utility functions shared across Floating UI packages. You may use these
functions in your own projects, but are subject to breaking changes.
