#!/usr/bin/env npx tsx
export {};
